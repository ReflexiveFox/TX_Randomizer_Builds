Thanks for downloading TX Randomizer!

This program will help you randomize your garage combo and your custom match parameters.

##### HOW TO INSTALL #####
1. Extract the .zip file in any folder you want
2. Find "TX Randomizer.exe" file in the extracted folder
3. Click on "TX Randomizer.exe" file to execute the program.

##### WARNING #####
DO NOT move / delete / edit any file inside the extracted folder, the program will not work in that case.

Log version 4.0
- Added Backhit Increase module